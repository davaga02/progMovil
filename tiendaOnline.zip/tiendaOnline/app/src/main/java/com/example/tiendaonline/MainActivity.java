package com.example.tiendaonline;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        obtenerLibros();
    }

    public void obtenerLibros(){

        apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);

        // Realiza la llamada al endpoint
        Call<List<Libro>> call = apiService.obtenerLibros();
        call.enqueue(new Callback<List<Libro>>(){


            @Override
            public void onResponse(Call<List<Libro>> call, Response<List<Libro>> response) {

                if(response.isSuccessful() && response.body() != null){
                    List<Libro> listaLibros = response.body();
                    LibroAdapter adapter = new LibroAdapter(MainActivity.this, listaLibros);
                    ListView listView  = findViewById(R.id.ListView);
                    listView.setAdapter(adapter);

                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                            // Obtener el libro seleccionado de la lista
                            Libro libroSeleccionado = (Libro) adapterView.getItemAtPosition(i);

                            Intent intent = new Intent(MainActivity.this, ItemActivity.class);
                            intent.putExtra("libro_id", libroSeleccionado.getId()); // Pasamos el id
                            startActivity(intent);
                        }
                    });

                    for (Libro l : listaLibros){
                        Log.d("Respuesta", l.toString());
                    }
                }else{
                    Log.e("API_ERROR", "Error: " + response.code());
                }

            }

            @Override
            public void onFailure(Call<List<Libro>> call, Throwable t) {
                Log.e("API_ERROR", t.getMessage());
            }

         });
    }
}

