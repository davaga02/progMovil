package com.example.tiendaonline;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ApiService {

    @GET("libros")
    Call<List<Libro>> obtenerLibros();

    @GET("{id}")
    Call<Libro> obtenerLibroPorId(@Path("id") int id);

}
