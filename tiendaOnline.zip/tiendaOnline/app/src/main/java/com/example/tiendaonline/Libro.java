package com.example.tiendaonline;

public class Libro {

    private Integer id;
    private String nombre;
    private String miniDescripcion;
    private double precio;
    private double precioOferta;
    private String imagenUrl;

    public Libro() {}

    public Libro(Integer id, String nombre, String miniDescripcion, double precio, double precioOferta,
                 String imagenUrl) {
        super();
        this.id = id;
        this.nombre = nombre;
        this.miniDescripcion = miniDescripcion;
        this.precio = precio;
        this.precioOferta = precioOferta;
        this.imagenUrl = imagenUrl;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMiniDescripcion() {
        return miniDescripcion;
    }

    public void setMiniDescripcion(String miniDescripcion) {
        this.miniDescripcion = miniDescripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public double getPrecioOferta() {
        return precioOferta;
    }

    public void setPrecioOferta(double precioOferta) {
        this.precioOferta = precioOferta;
    }

    public String getImagenUrl() {
        return imagenUrl;
    }

    public void setImagenUrl(String imagenUrl) {
        this.imagenUrl = imagenUrl;
    }


    @Override
    public String toString() {
        return "Libro{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", miniDescripcion='" + miniDescripcion + '\'' +
                ", precio=" + precio +
                ", precioOferta=" + precioOferta +
                ", imagenUrl='" + imagenUrl + '\'' +
                '}';
    }
}
