package com.example.tiendaonline;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class LibroAdapter extends BaseAdapter {

    private Context context;
    private List<Libro> libros;

    public LibroAdapter(Context context, List<Libro> libros) {
        this.context = context;
        this.libros = libros;
    }


    @Override
    public int getCount() {
        return libros.size();
    }

    @Override
    public Object getItem(int position) {
        return libros.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.activity_item, viewGroup, false);
        }

        // Obtener el libro actual
        Libro libro = libros.get(position);

        // Vincular datos con vistas
        TextView nombreProducto = view.findViewById(R.id.textViewNombreProducto);
        TextView descripcion = view.findViewById(R.id.textViewMiniDescripcion);
        TextView precio = view.findViewById(R.id.textViewPrecioOriginal);
        TextView precioOferta = view.findViewById(R.id.textViewPrecioOferta);
        //ImageView imageView = view.findViewById(R.id.imageView);

        nombreProducto.setText(libro.getNombre());
        descripcion.setText(libro.getMiniDescripcion());
        precio.setText(String.valueOf(libro.getPrecio()));
        precioOferta.setText(String.valueOf(libro.getPrecioOferta()));

        return view;
    }
}
