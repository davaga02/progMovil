package com.example.tiendaonline;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ItemActivity extends AppCompatActivity {

    private ImageView imageViewDetalle;
    private TextView textViewNombreDetalle, textViewDescripcionDetalle, textViewPrecioOriginalDetalle, textViewPrecioOfertaDetalle;
    private Button buttonAgregarCarrito;
    ApiService apiService;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_item);

        imageViewDetalle = findViewById(R.id.imageViewDetalle);
        textViewNombreDetalle = findViewById(R.id.textViewNombreDetalle);
        textViewDescripcionDetalle = findViewById(R.id.textViewDescripcionDetalle);
        textViewPrecioOriginalDetalle = findViewById(R.id.textViewPrecioOriginalDetalle);
        textViewPrecioOfertaDetalle = findViewById(R.id.textViewPrecioOfertaDetalle);
        buttonAgregarCarrito = findViewById(R.id.buttonAgregarCarrito);

       // Obtener el ID del producto desde el Intent
        int libroId = getIntent().getIntExtra("libro_id", -1); // Valor por defecto -1

        obtenerDetalleLibro(libroId);
    }

    public void obtenerDetalleLibro(int id){

        apiService = RetrofitClient.getRetrofitInstance().create(ApiService.class);
        Call<Libro> call = apiService.obtenerLibroPorId(id);
        call.enqueue(new Callback<Libro>() {
            @Override
            public void onResponse(Call<Libro> call, Response<Libro> response) {

                if (response.isSuccessful()) {
                    Libro libro = response.body();

                    // Verifica que el objeto no sea null
                    if (libro != null) {
                        // Ahora puedes acceder a los datos del libro
                        String nombre = libro.getNombre();
                        String descripcion = libro.getMiniDescripcion();
                        double precio = libro.getPrecio();
                        double precioOferta = libro.getPrecioOferta();
                        String imagenUrl = libro.getImagenUrl();

                        // Aquí actualizas tu UI con los datos del libro
                        // Por ejemplo, actualizar los TextViews con los datos del libro
                        textViewNombreDetalle.setText(nombre);
                        textViewDescripcionDetalle.setText(descripcion);
                        textViewPrecioOriginalDetalle.setText("€" + precio);
                        textViewPrecioOfertaDetalle.setText("€" + precioOferta);
                        // Usa una librería como Glide o Picasso para cargar la imagen
                    } else {
                        // Maneja el caso en el que la respuesta es exitosa pero el libro es null
                        Log.e("ItemActivity", "El libro no existe o no se encontró.");
                    }
                } else {
                    // Maneja el caso en el que la respuesta no es exitosa
                    Log.e("ItemActivity", "Error en la respuesta de la API: " + response.message());
                }


            }

            @Override
            public void onFailure(Call<Libro> call, Throwable t) {
                Log.e("API_ERROR", t.getMessage());
            }
        });
    }


}
