package com.example.marcadordeportes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityMarcadorTenis extends AppCompatActivity {

    private int puntosEquipo1 = 0;
    private int puntosEquipo2 = 0;
    private TextView equipo1;
    private TextView equipo2;
    private RadioButton radioBtneq1;
    private RadioButton radioBtneq2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.marcador_tenis);

        // Vincular vistas
        equipo1 = findViewById(R.id.txtViewEquipo1);
        equipo2 = findViewById(R.id.txtViewEquipo2);
        radioBtneq1 = findViewById(R.id.radioBtnEquipo1);
        radioBtneq2 = findViewById(R.id.radioBtnEquipo2);

        // Inicializar marcador
        equipo1.setText("0");
        equipo2.setText("0");
    }

    public void onClickSumarTenis(View view) {

        if (radioBtneq1.isChecked()) {

            puntosEquipo1 = sumarPuntuacion(puntosEquipo1);

            if (puntosEquipo1 == -1) {

                Toast.makeText(this, "¡Equipo 1 ha ganado el juego!", Toast.LENGTH_SHORT).show();
                puntosEquipo1 = 0; // Reinicia la puntuación para el siguiente juego
                puntosEquipo2 = 0;
            }

            actualizarMarcador();
            radioBtneq1.setChecked(false);

        } else if (radioBtneq2.isChecked()) {

            puntosEquipo2 = sumarPuntuacion(puntosEquipo2);

            if (puntosEquipo2 == -1) {

                Toast.makeText(this, "¡Equipo 2 ha ganado el juego!", Toast.LENGTH_SHORT).show();
                puntosEquipo1 = 0; // Reinicia la puntuación para el siguiente juego
                puntosEquipo2 = 0;
            }

            actualizarMarcador();
            radioBtneq2.setChecked(false);
        } else {
            Toast.makeText(this, "Selecciona un equipo para sumar puntos", Toast.LENGTH_SHORT).show();
        }
    }

    public void onClickRestarTenis(View view) {

        if (radioBtneq1.isChecked()) {

            if (puntosEquipo1 == 0) {
                Toast.makeText(this, "No puedes restar más puntos", Toast.LENGTH_SHORT).show();
            } else {
                puntosEquipo1 = restarPuntuacion(puntosEquipo1);
                actualizarMarcador();
            }

            radioBtneq1.setChecked(false);

        } else if (radioBtneq2.isChecked()) {
            if (puntosEquipo2 == 0) {
                Toast.makeText(this, "No puedes restar más puntos", Toast.LENGTH_SHORT).show();
            } else {
                puntosEquipo2 = restarPuntuacion(puntosEquipo2);
                actualizarMarcador();
            }
            radioBtneq2.setChecked(false);
        } else {
            Toast.makeText(this, "Selecciona un equipo para restar puntos", Toast.LENGTH_SHORT).show();
        }
    }

    public void onClickFinalizarTenis(View view) {
        Intent i = new Intent(ActivityMarcadorTenis.this, ActivityElegirDeporte.class);
        startActivity(i);
    }

    // Método para avanzar en la puntuación
    public int sumarPuntuacion(int puntuacion) {
        switch (puntuacion) {
            case 0:
                return 15;
            case 15:
                return 30;
            case 30:
                return 40;
            case 40:
                return -1; // Indica que el jugador ganó el juego
            default:
                return 0;
        }
    }

    // Método para retroceder en la puntuación
    public int restarPuntuacion(int puntuacion) {
        switch (puntuacion) {
            case 40:
                return 30;
            case 30:
                return 15;
            case 15:
                return 0;
            default:
                return 0;
        }
    }

    // Actualiza el marcador visual
    private void actualizarMarcador() {
        equipo1.setText(String.valueOf(puntosEquipo1));
        equipo2.setText(String.valueOf(puntosEquipo2));
    }
}