package com.example.marcadordeportes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main4), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }



    public void iniciarSesion(View view) {

        final String usu = "manu";
        final String contr = "1234";



        EditText usuario = findViewById(R.id.editTxtUsuario);
        EditText contrasenya = findViewById(R.id.editTxtContrasenya);

        if(usuario.getText().toString().equals(usu) &&
                contrasenya.getText().toString().equals(contr)){

            Intent intent = new Intent(MainActivity.this, ActivityElegirDeporte.class);
            startActivity(intent);

        }else{

            Toast t = Toast.makeText(MainActivity.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT);
            t.show();
        }
    }
}