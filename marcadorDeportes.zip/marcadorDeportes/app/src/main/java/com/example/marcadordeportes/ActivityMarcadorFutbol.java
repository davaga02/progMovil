package com.example.marcadordeportes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ActivityMarcadorFutbol extends AppCompatActivity {

    private int puntosEquipo1 = 0;
    private int puntosEquipo2 = 0;
    private TextView equipo1;
    private TextView equipo2;
    private RadioButton radioBtneq1;
    private RadioButton radioBtneq2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.marcador_futbol);

        equipo1 = (TextView) findViewById(R.id.txtViewEquipo1);
        equipo2 = (TextView) findViewById(R.id.txtViewEquipo2);
        radioBtneq1 = (RadioButton) findViewById(R.id.radioBtnEquipo1);
        radioBtneq2 = (RadioButton) findViewById(R.id.radioBtnEquipo2);


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main4), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


    }

    public void onClickSumar(View view) {

        if(radioBtneq1.isChecked()){
            puntosEquipo1 = puntosEquipo1 + 2;
            equipo1.setText(String.valueOf(puntosEquipo1));

        }else if(radioBtneq2.isChecked()){
            puntosEquipo2 = puntosEquipo2 + 2;
            equipo2.setText(String.valueOf(puntosEquipo2));

        }else{
            Toast t = Toast.makeText(this, "Selecciona un equipo para sumar puntos", Toast.LENGTH_SHORT);
            t.show();
        }

    }

    public void onClickRestar(View view) {

        if (radioBtneq1.isChecked()){

            if (puntosEquipo1 < 2){
                Toast t = Toast.makeText(ActivityMarcadorFutbol.this, "No puedes restar mas puntos", Toast.LENGTH_SHORT);
                t.show();
            }else {
                puntosEquipo1 = puntosEquipo1 - 2;
                equipo1.setText(String.valueOf(puntosEquipo1));
                radioBtneq1.setChecked(false);
            }


        }else if(radioBtneq2.isChecked()){

            if (puntosEquipo2 < 2){
                Toast t = Toast.makeText(ActivityMarcadorFutbol.this, "No puedes restar mas puntos", Toast.LENGTH_SHORT);
                t.show();
            }else {
                puntosEquipo2 = puntosEquipo2 - 2;
                equipo2.setText(String.valueOf(puntosEquipo2));
                radioBtneq2.setChecked(false);
            }


        }else {
            Toast.makeText(this, "Selecciona un equipo para restar puntos", Toast.LENGTH_SHORT).show();
        }
    }

    public void onClickFinalizar(View view) {

        Intent i = new Intent(ActivityMarcadorFutbol.this, ActivityElegirDeporte.class);
        startActivity(i);
    }


}
