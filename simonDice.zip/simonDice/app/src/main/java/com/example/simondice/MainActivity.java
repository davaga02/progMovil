package com.example.simondice;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    TextView nivel;
    Button btn1;
    Button btn2;
    Button btn3;
    Button btn4;
    private ArrayList<Integer> secuencia = new ArrayList<>();
    private ArrayList<Integer> secuenciaJugador = new ArrayList<>();
    Random r = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        nivel = findViewById(R.id.txtNivel);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


    }

    public void onClickPlay(View view) {

        generarSecuencia();
        iluminarBotones(secuencia);



    }

    public void generarSecuencia(){

        for (int i = 0; i < 4; i++){

            secuencia.add(r.nextInt(4));
        }

    }

    public void iluminarBotones(ArrayList<Integer> secuencia){


        for (int i = 0; i < secuencia.size(); i++){

            if (secuencia.get(i) == 0){

                new Handler().postDelayed(() -> {
                    btn1.setBackgroundColor(Color.parseColor("#6A9FDA"));  // Restaurar el color original
                }, 1000);  // 1000 ms = 1 segundo
            }

            if (secuencia.get(i) == 1){

                new Handler().postDelayed(() -> {
                    btn2.setBackgroundColor(Color.parseColor("#D5707F"));  // Restaurar el color original
                }, 1000);  // 1000 ms = 1 segundo
            }

            if (secuencia.get(i) == 2){

                new Handler().postDelayed(() -> {
                    btn3.setBackgroundColor(Color.parseColor("#D1A92E")); // Restaurar el color original
                }, 1000);  // 1000 ms = 1 segundo
            }

            if (secuencia.get(i) == 3){

                new Handler().postDelayed(() -> {
                    btn4.setBackgroundColor(Color.parseColor("#7A9E4D")); // Restaurar el color original
                }, 1000);  // 1000 ms = 1 segundo
            }
        }
    }
}
