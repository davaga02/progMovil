package com.example.comunicacionesredact3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    public ListView fileListView;
    public Button btnDescaegar;
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        cargarLista();
    }

    public void cargarLista(){

        String url = "http://localhost/psp/list.txt";
        GestorDescargas gd = new GestorDescargas();
        gd.descargarArchivo(url, "list.txt");

        try{

            FileReader fl = new FileReader("list.txt");
            BufferedReader br = new BufferedReader(fl);

            String linea;
            while ((linea = br.readLine()) != null){

                fileListView.getItems().add(linea);
            }

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public void descargarClick(ActionEvent actionEvent) {

        GestorDescargas gd = new GestorDescargas();
        String archivoSeleccionado = fileListView.getSelectionModel().getSelectedItem().toString();

        String url = "http://localhost/psp/";
        if (archivoSeleccionado != null){
            gd.descargarArchivo(url + archivoSeleccionado, archivoSeleccionado);

            Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Archivo descargado correctamente");
            a.show();
        }else {

            Alert a = new Alert(Alert.AlertType.ERROR, "Error en la descarga del archivo" );
            a.show();
        }
    }




}