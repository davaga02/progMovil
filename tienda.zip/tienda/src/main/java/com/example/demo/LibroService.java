package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LibroService {
	
	@Autowired
	private LibroRepository libroRepository;
	
	public List<Libro> obtenerLibros(){
		
		return libroRepository.findAll();
	}
	
	 public Libro obtenerProductoPorId(int id) {
	        // Si no se encuentra el producto, puedes devolver un valor null o lanzar una excepción
	        return libroRepository.findById(id).orElse(null);
	    }

}
