package com.example.supabaseapphoroscopos;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private SupabaseService supabaseService;
    private List<Usuario> usuarios;
    EditText nombreUsuarioField ;
    EditText contrasenyaUsuarioField;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://tlirrpxslqbeksrpgrok.supabase.co")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        supabaseService = retrofit.create(SupabaseService.class);

        obtenerUsuarios();
    }

    private void obtenerUsuarios(){

        supabaseService.getUsuarios().enqueue(new Callback<List<Usuario>>() {
            @Override
            public void onResponse(Call<List<Usuario>> call, Response<List<Usuario>> response) {

                if(response.isSuccessful() && response.body() != null){

                    usuarios = response.body();

                    for (Usuario us : usuarios ) {
                        Log.d("Usuario", "Nombre: " + us.getNombreUsuario() + ", Contraseña: " + us.getContrasenya() + ", Signo: " + us.getSigno());
                    }
                }else{
                    Log.e("Error", "Error en la respuesta: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<List<Usuario>> call, Throwable t) {

                Log.e("Error", "Error en la llamada: " + t.getMessage());
            }
        });
    }


    public void clickIniciarSesion(View view) {

        nombreUsuarioField = findViewById(R.id.editTextNombre);
        contrasenyaUsuarioField = findViewById(R.id.editTextContrasenya);

        String nombreUsuario = nombreUsuarioField.getText().toString();
        String contrasenyaUsuario = contrasenyaUsuarioField.getText().toString();

        for (Usuario us : usuarios) {

            if (us.getNombreUsuario().equals(nombreUsuario) && us.getContrasenya().equals(contrasenyaUsuario)){

                Toast.makeText(this, "Correcto", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, inicio.class);
                intent.putExtra("usuario", us);
                startActivity(intent);


            }else{
                Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
            }
        }
    }
}