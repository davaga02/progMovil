package com.example.supabaseapphoroscopos;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class inicio extends AppCompatActivity {

    private SupabaseService supabaseService;
    private List<String> mensajes;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.inicio);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent i = getIntent();
        Usuario u = (Usuario) i.getSerializableExtra("usuario");

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://tlirrpxslqbeksrpgrok.supabase.co")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        supabaseService = retrofit.create(SupabaseService.class);

    }

    public void obtenerMensaje(){

        supabaseService.getMensajes().enqueue(new Callback<List<String>>() {
            @Override
            public void onResponse(Call<List<String>> call, Response<List<String>> response) {

                if (response.isSuccessful() && response.body() != null){

                    mensajes = response.body();

                }else{
                    Log.e("Error", "Error en la respuesta: " + response.message());
                }


            }

            @Override
            public void onFailure(Call<List<String>> call, Throwable t) {

                Log.e("Error", "Error en la llamada: " + t.getMessage());

            }
        });
    }
}
