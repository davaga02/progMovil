package com.example.supabaseapphoroscopos;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface SupabaseService {

    @Headers({
            "apikey: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsaXJycHhzbHFiZWtzcnBncm9rIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI2OTM0ODcsImV4cCI6MjA0ODI2OTQ4N30.-00o9U1J3hGhuayKYvgfRWZ1IGY7RWfXd4_EA-pOaJM",
            "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsaXJycHhzbHFiZWtzcnBncm9rIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI2OTM0ODcsImV4cCI6MjA0ODI2OTQ4N30.-00o9U1J3hGhuayKYvgfRWZ1IGY7RWfXd4_EA-pOaJM"
    })
    @GET("rest/v1/usuarios")
    Call<List<Usuario>> getUsuarios();

    @Headers({
            "apikey: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsaXJycHhzbHFiZWtzcnBncm9rIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI2OTM0ODcsImV4cCI6MjA0ODI2OTQ4N30.-00o9U1J3hGhuayKYvgfRWZ1IGY7RWfXd4_EA-pOaJM",
            "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsaXJycHhzbHFiZWtzcnBncm9rIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI2OTM0ODcsImV4cCI6MjA0ODI2OTQ4N30.-00o9U1J3hGhuayKYvgfRWZ1IGY7RWfXd4_EA-pOaJM"
    })
    @GET("rest/v1/mensajes")
    Call<List<String>> getMensajes();

}
