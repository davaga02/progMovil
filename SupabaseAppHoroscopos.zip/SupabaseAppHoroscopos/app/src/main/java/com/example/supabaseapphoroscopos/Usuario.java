package com.example.supabaseapphoroscopos;

import java.io.Serializable;

public class Usuario implements Serializable {

    private String nombreUsuario;
    private String contrasenya;
    private String signo;


    public Usuario(String nombreUsuario, String contrasenya, String signo) {
        this.nombreUsuario = nombreUsuario;
        this.contrasenya = contrasenya;
        this.signo = signo;
    }


    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getContrasenya() {
        return contrasenya;
    }

    public void setContrasenya(String contrasenya) {
        this.contrasenya = contrasenya;
    }

    public String getSigno() {
        return signo;
    }

    public void setSigno(String signo) {
        this.signo = signo;
    }
}
